Handles all score and score-related activities.

To do
	Make a proper-front end. The current versions are only a crude prototype.


ALL COMMITS MUST BE PUSHED TO 'DEVELOP' BRANCH
