<?php
/*
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "sports_db";
*/

$servername = "localhost";
$username = "athletics";
$password = "amrita_108";
$dbname = "athletics";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$dept1 = 0; $dept2 = 0; $dept3 = 0;
$score1 = 0; $score2 = 0; $score3 = 0; 

$c1 = $_POST["pos1_chest"];
$t1 = $_POST["pos1_time"];

//echo "<br> ".$c1." ".$t1."<br>";

$c2 = $_POST["pos2_chest"];
$t2 = $_POST["pos2_time"];

$c3 = $_POST["pos3_chest"];
$t3 = $_POST["pos3_time"];


$pos1_updatequery = "UPDATE  `Heats_100F` SET  `time` = \"$t1\" WHERE  `chest` = $c1 ";
$pos2_updatequery = "UPDATE  `Heats_100F` SET  `time` = \"$t2\" WHERE  `chest` = $c2 ";
$pos3_updatequery = "UPDATE  `Heats_100F` SET  `time` = \"$t3\" WHERE  `chest` = $c3 ";

$getDeptQuery1 = "SELECT `batch` FROM `STUDENT` WHERE `CHEST` = $C1 ";
$getDeptQuery2 = "SELECT `batch` FROM `STUDENT` WHERE `CHEST` = $C2 ";
$getDeptQuery3 = "SELECT `batch` FROM `STUDENT` WHERE `CHEST` = $C3 "; 

	if (mysqli_query($conn, $pos1_updatequery)) {
		$dept1 = mysqli_query($conn, $getDeptQuery1);
		if( $dept1 == "u_cse" or $dept1 == "p_cyb" or $dept1 == "p_elr" or $dept1 == "p_wna" )	 {
			
			$getScoreQuery1 = "SELECT `SCORE` FROM `deptscore` WHERE `DEPT` LIKE '$dept1' ";
					
			$score1 = mysqli_query($conn, $getScoreQuery1);
			$score1 = $score1 + 10;
			
			$scoreUpdateQuery = "UPDATE `deptscore` SET `SCORE` = $score1 WHERE `DEPT` LIKE '$dept1' ";
			
			if( mysqli_query($conn, $scoreUpdateQuery) )	{
				echo "Department score updated!";
			}
			else {
				echo "Could not update department score!";
			}
		}
		else {
			echo "NOT CSE";
		}
			
		echo "New record created successfully";
		
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}


if (mysqli_query($conn, $pos2_updatequery)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


if (mysqli_query($conn, $pos3_updatequery)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


echo "<br> Dept: ".$dept1;
echo "<br> Score: ".$score1;

mysqli_close($conn);

?> 
